var police,corona;

function preload(){
  policeImage=loadImage("police.jpg");
  backgroundImage=loadImage("background.jpg");
  lokiImage=loadImage("loki.jpg");
}
function setup() {
   createCanvas(700, 700);
  
    police=createSprite(150,60,10,10);
  police.addImage(policeImage);
  police.scale = 1.5;
  
  background=createSprite(200,200,20,20);
   background.addImage(backgroundImage);
  background.scale = 2.5;
  
  loki=createSprite(450,250,20,20);
  loki.addImage(lokiImage);
  loki.scale=0.7;
  
  
  
}

function draw() {
   background.velocityX = -3 

    if (background.x < 0){
      background.x = background.width/2;
    }
  drawSprites();
}  